<?php
// Handle payment failure
echo "<script>
        alert('Payment failed. Please try again.');
        window.location.href = 'membership.php';
      </script>";
?>
